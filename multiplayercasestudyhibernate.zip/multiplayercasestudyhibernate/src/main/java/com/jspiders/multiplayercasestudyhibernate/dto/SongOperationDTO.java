package com.jspiders.multiplayercasestudyhibernate.dto;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class SongOperationDTO {
	
	private static EntityManagerFactory factory ;
	private static EntityManager manager ;
	private static EntityTransaction transaction ;
	private static Scanner scanner = new Scanner(System.in);
	
	private static int id;
	private static String songName;
	private static String singer ;
	private static int duration ;
	private static String movie_album ;
	private static String lyricist ;

	private static void openConnection() {
		
		factory = Persistence.createEntityManagerFactory("MusicPlayer");
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
	}
	
	public  static void closeConnection() {
		
		if( factory != null ) {
			
			factory.close();
			
		}
		
		if( manager != null ) {
			
			manager.close();
			
		}
		
		if( transaction.isActive() ) {
			
			transaction.rollback();
			
		}
	}
	
	public void addSongs() {
		
		openConnection();
		
		transaction.begin();
		
		SongDTO song = new SongDTO();
		
        System.out.println("\n How many songs you want to add? \n");
		
		int choice = scanner.nextInt();
		
		for (int i = 1; i <= choice; i++) {

			System.out.println(" Enter the id of the song : \n");
			 id = scanner.nextInt();
			 song.setId(id);

			System.out.println(" Enter the name of the song : \n");
			 songName = scanner.next();
			 song.setSongName(songName);

			System.out.println(" Enter the singer of the song : \n");
			 singer = scanner.next();
			 song.setSinger(singer);

			System.out.println(" Enter the duration of the song : \n");
			 duration = scanner.nextInt();
			 song.setDuration(duration);

			System.out.println(" Enter the movie/album of the song : \n");
			 movie_album = scanner.next();
			 song.setMovie_album(movie_album);

			System.out.println(" Enter the lyricist of the song : \n");
			 lyricist = scanner.next();
			 song.setLyricist(lyricist);
			 
			 System.out.println( "\n" + songName + " successfully added to the playlist..!! \n");
			 
			 manager.persist(song);
			 
			 transaction.commit();
		
		}
		
		closeConnection();
		
	}
	
	public void removeSongs() {
		
		openConnection();
		
		transaction.begin();
		
		
		
		System.out.println(" \n Enter the id of the song which you want to delete : \n");
		 id = scanner.nextInt();
		
		SongDTO song = manager.find(SongDTO.class, id);
		
		manager.remove(song);
		
		transaction.commit();
		
		closeConnection();
		
	}
	
	  public void subMainMenu1() {
		  
		  System.out.println(" \n ==========MENU==========");
			System.out.println("1. Add a Song\n"
					+ "2. Remove a song\n"
					+ "3. Go Back \n"
					+ "4. Exit \n");
		  
	  }
	
}
