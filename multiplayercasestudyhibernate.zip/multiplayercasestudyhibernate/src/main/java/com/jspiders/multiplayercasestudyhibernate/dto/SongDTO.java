package com.jspiders.multiplayercasestudyhibernate.dto;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class SongDTO {

	@Id
    private int id;
	
	private String songName;
	
	private String singer;
	
	private double duration;
	
	private String movie_album;
	
	private String lyricist;
}
