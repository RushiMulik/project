package com.jspiders.multiplayercasestudyhibernate.dao;

import java.util.Scanner;

import com.jspiders.multiplayercasestudyhibernate.dto.SongOperationDTO;

public class MusicPlayerDAO {
	
	private static boolean loop = true;
	private static int choice;
	private static Scanner scanner = new Scanner(System.in);
	private static SongOperationDTO operations = new SongOperationDTO();
	
	public static void main(String[] args) {
		
		musicPlayer();
			
	}

   private static void musicPlayer() {
		
		while (loop) {
			
			operations.subMainMenu1();
			
			choice = scanner.nextInt();
			
			switch (choice) {
			
			case 1:
				
				operations.addSongs();
				break;
				
			case 2:
				
				operations.removeSongs();
				break;
				
			case 3:

				musicPlayer();
				break;
				
			case 4:
				
				System.out.println("Thank you...!!!");
				loop = false;
				break;
				
			default:
				System.out.println("Invalid choice. Try again...!!!");
				break;
			}
       }
   }
}
